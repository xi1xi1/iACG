class AppEnv {
  static const String supabaseUrl = 'https://vzxrqxyoshkvwoaxzjzc.supabase.co';
  static const String supabaseAnonKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ6eHJxeHlvc2hrdndvYXh6anpjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIyNDUzNjksImV4cCI6MjA3NzgyMTM2OX0.izPo42wmWdIYQc0dGA8Z0gRP3ZHdyFelnS0oZMcYG7s';

  // 可以在这里添加其他环境变量
  static const bool isDebug = true;
}
