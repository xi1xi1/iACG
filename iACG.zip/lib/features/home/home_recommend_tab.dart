import 'package:flutter/material.dart';
import '../../services/post_service.dart';
import '../../widgets/post_card.dart';
import '../../widgets/loading_view.dart';
import '../../widgets/error_view.dart';
import '../../widgets/empty_view.dart';

class HomeRecommendTab extends StatefulWidget {
  const HomeRecommendTab({super.key});

  @override
  State<HomeRecommendTab> createState() => _HomeRecommendTabState();
}

class _HomeRecommendTabState extends State<HomeRecommendTab> {
  final List<Map<String, dynamic>> _posts = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadPosts();
  }

  Future<void> _loadPosts() async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });

      final result = await PostService().fetchRecommendPosts();
      setState(() {
        _posts.clear();
        _posts.addAll(result);
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return const LoadingView();
    if (_error != null) return ErrorView(error: _error!);
    if (_posts.isEmpty) return const EmptyView();

    // 将帖子分成左右两列
    List<Map<String, dynamic>> leftPosts = [];
    List<Map<String, dynamic>> rightPosts = [];

    for (int i = 0; i < _posts.length; i++) {
      if (i % 2 == 0) {
        leftPosts.add(_posts[i]);
      } else {
        rightPosts.add(_posts[i]);
      }
    }

    return RefreshIndicator(
      // //单列实现
      // onRefresh: _loadPosts,
      // child: ListView.builder(
      //   padding: const EdgeInsets.all(16),
      //   itemCount: _posts.length,
      //   itemBuilder: (context, index) {
      //     final post = _posts[index];
      //     return PostCard(post: post);
      //   },
      // ),

      //双列实现
      onRefresh: _loadPosts,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8), // 整体水平内边距
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 左列
            Expanded(
              child: ListView.builder(
                physics: const BouncingScrollPhysics(),
                itemCount: leftPosts.length,
                itemBuilder: (context, index) {
                  final post = leftPosts[index];
                  return PostCard(
                    post: post,
                    isLeftColumn: true, // 告诉卡片在左列
                  );
                },
              ),
            ),

            // 列间距
            const SizedBox(width: 8),

            // 右列
            Expanded(
              child: ListView.builder(
                physics: const BouncingScrollPhysics(),
                itemCount: rightPosts.length,
                itemBuilder: (context, index) {
                  final post = rightPosts[index];
                  return PostCard(
                    post: post,
                    isLeftColumn: false, // 告诉卡片在右列
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
